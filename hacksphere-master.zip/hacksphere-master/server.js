// server.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Store connected clients and their metadata
const clients = new Map();

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'public')));

wss.on('connection', (ws) => {
    console.log('New client connected');
    
    // Generate a unique ID for this client
    const clientId = generateId();
    clients.set(clientId, { ws, metadata: null });
    
    ws.on('message', (message) => {
        console.log(`Received from ${clientId}:`, message);
        try {
            const data = JSON.parse(message);
            handleMessage(clientId, data);
        } catch (err) {
            console.error('Error parsing message:', err);
        }
    });
    
    ws.on('close', () => {
        console.log('Client disconnected');
        clients.delete(clientId);
    });
});

function handleMessage(clientId, data) {
    const client = clients.get(clientId);
    
    switch (data.type) {
        case 'register':
            // Client registers its type (viewer or streamer)
            client.metadata = { type: data.clientType };
            console.log(`Client ${clientId} registered as ${data.clientType}`);
            break;
            
        case 'offer':
        case 'answer':
        case 'candidate':
            // Forward signaling messages to the appropriate peer
            forwardMessage(clientId, data);
            break;
            
        case 'request-stream':
            // Handle request for a new stream
            handleStreamRequest(clientId, data);
            break;
            
        default:
            console.log('Unknown message type:', data.type);
    }
}

function forwardMessage(senderId, message) {
    // In a real app, you'd have logic to determine the recipient
    // For now, we'll just broadcast to all other clients of the opposite type
    const sender = clients.get(senderId);
    console.log(`Forwarding ${message.type} from ${senderId} to peers`);
    
    clients.forEach((client, id) => {
        if (id !== senderId && 
            client.metadata && 
            client.metadata.type !== sender.metadata.type) {
            client.ws.send(JSON.stringify(message));
        }
    });
}

function handleStreamRequest(clientId, data) {
    // Here you would implement logic to start a new Waydroid container
    // and connect it to the requesting client
    console.log(`Stream request from ${clientId} for app ${data.appId}`);
    
    // In a real implementation, you'd:
    // 1. Launch Waydroid container with the requested app
    // 2. Connect the container as a "streamer" client to this server
    // 3. Pair the viewer with the new streamer
}

function generateId() {
    return Math.random().toString(36).substring(2, 15);
}

// Add this to server.js (temporary test endpoint)
app.get('/simulate-streamer', (req, res) => {
    const fakeStreamer = new WebSocket(`ws://localhost:${PORT}`);
    
    fakeStreamer.on('open', () => {
        fakeStreamer.send(JSON.stringify({
            type: 'register',
            clientType: 'streamer'
        }));

        // Simulate sending an offer
        setTimeout(() => {
            fakeStreamer.send(JSON.stringify({
                type: 'offer',
                sdp: "v=0\r\no=- 123456 2 IN IP4 127.0.0.1\r\n..."
            }));
        }, 1000);
    });

    res.send("Waydroid streamer started");
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});